import Vue from "vue";
import Buefy from "buefy";
import "@/assets/scss/buefy.scss";
import "@mdi/font/css/materialdesignicons.css";

Vue.use(Buefy);
