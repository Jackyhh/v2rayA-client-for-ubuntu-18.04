#!/bin/sh

systemctl disable v2raya || true
systemctl stop v2raya || true
