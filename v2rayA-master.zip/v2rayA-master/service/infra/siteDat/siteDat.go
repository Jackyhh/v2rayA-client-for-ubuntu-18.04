package siteDat

type SiteDat struct {
	Filename string   `json:"filename"`
	Tags     []string `json:"tags"`
}
